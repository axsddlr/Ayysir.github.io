webpackJsonp([ 1 ], {
    728: function(module, exports, __webpack_require__) {
        "use strict";
        __webpack_require__(729), __webpack_require__.p = window.Sonarr.urlBase + "/";
    },
    729: function(module, exports, __webpack_require__) {
        "use strict";
        Object.defineProperty(exports, "__esModule", {
            value: !0
        });
        var _jquery2 = _interopRequireDefault(__webpack_require__(26));
        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }
        (0, _interopRequireDefault(__webpack_require__(769)).default)(_jquery2.default);
        var jquery = _jquery2.default;
        window.$ = _jquery2.default, window.jQuery = _jquery2.default, exports.default = jquery;
    },
    769: function(module, exports, __webpack_require__) {
        "use strict";
        Object.defineProperty(exports, "__esModule", {
            value: !0
        }), exports.default = function() {
            var originalAjax = _jquery2.default.ajax;
            _jquery2.default.ajax = function(xhr) {
                return xhr && function(xhr) {
                    return !absUrlRegex.test(xhr.url);
                }(xhr) && (function(xhr) {
                    xhr.data && "DELETE" === xhr.type && (xhr.url.contains("?") ? xhr.url += "&" : xhr.url += "?", 
                    xhr.url += _jquery2.default.param(xhr.data), delete xhr.data);
                }(xhr), function(xhr) {
                    xhr.url.startsWith("/signalr") ? xhr.url = urlBase + xhr.url : xhr.url = apiRoot + xhr.url;
                }(xhr), function(xhr) {
                    xhr.headers = xhr.headers || {}, xhr.headers["X-Api-Key"] = window.Sonarr.apiKey;
                }(xhr)), originalAjax.apply(this, arguments);
            };
        };
        var obj, _jquery = __webpack_require__(26), _jquery2 = (obj = _jquery) && obj.__esModule ? obj : {
            default: obj
        };
        var absUrlRegex = /^(https?:)?\/\//i, apiRoot = window.Sonarr.apiRoot, urlBase = window.Sonarr.urlBase;
    }
}, [ 728 ]);
//# sourceMappingURL=preload.js.map